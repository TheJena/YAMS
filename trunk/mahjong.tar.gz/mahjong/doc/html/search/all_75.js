var searchData=
[
  ['undo_5flast_5ftwo_5fcouples',['undo_last_two_couples',['../game_8cc.html#a5817aa88950e75d367e13635d2a72a8f',1,'undo_last_two_couples():&#160;game.cc'],['../game_8h.html#a5817aa88950e75d367e13635d2a72a8f',1,'undo_last_two_couples():&#160;game.cc']]],
  ['unlocked',['unlocked',['../movements_8cc.html#add53a744140961284d8ab2cf817f4bb7',1,'movements.cc']]]
];
