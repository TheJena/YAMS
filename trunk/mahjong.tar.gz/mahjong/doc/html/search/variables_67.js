var searchData=
[
  ['g',['g',['../structcolour.html#a1a9e5fd626d7208a0af8c2b7552cd98f',1,'colour']]],
  ['gold',['gold',['../gui_8cc.html#a25ad47c423ba3fddd6c04046b94bfbb2',1,'gui.cc']]],
  ['green_5fforest',['green_forest',['../gui_8cc.html#a60d4ceb3ed21cf2ea74af213983569c0',1,'gui.cc']]]
];
