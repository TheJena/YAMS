var searchData=
[
  ['r',['r',['../structcolour.html#aec1c118c8b67a3911529dd573e5d7f79',1,'colour']]],
  ['redraw_5fwidget',['redraw_widget',['../gui_8cc.html#a4773b5a38c2eb4d3cc1208c0872483e2',1,'redraw_widget(const char *name):&#160;gui.cc'],['../gui_8h.html#a4773b5a38c2eb4d3cc1208c0872483e2',1,'redraw_widget(const char *name):&#160;gui.cc']]],
  ['refresh_5fdown_5flabel',['refresh_down_label',['../gui_8cc.html#a38f793aa7da6366779255005fde3ef13',1,'refresh_down_label(const int &amp;couples):&#160;gui.cc'],['../gui_8h.html#a38f793aa7da6366779255005fde3ef13',1,'refresh_down_label(const int &amp;couples):&#160;gui.cc']]],
  ['refresh_5fpair_5fremoved',['refresh_pair_removed',['../gui_8cc.html#ababb1e75110f02986338b4fbce1cc8b9',1,'refresh_pair_removed(const p_player &amp;temp, const int &amp;a, const int &amp;b):&#160;gui.cc'],['../gui_8h.html#ababb1e75110f02986338b4fbce1cc8b9',1,'refresh_pair_removed(const p_player &amp;temp, const int &amp;a, const int &amp;b):&#160;gui.cc']]],
  ['refresh_5fscores',['refresh_scores',['../game_8cc.html#a6d71742a4f6bf95ed5a9f35e5b24f0c0',1,'refresh_scores():&#160;game.cc'],['../game_8h.html#a6d71742a4f6bf95ed5a9f35e5b24f0c0',1,'refresh_scores():&#160;game.cc']]],
  ['refresh_5fscores_5flabels',['refresh_scores_labels',['../gui_8cc.html#a71a1ac39fe89b4eaf3a7d4b0bc8c4633',1,'refresh_scores_labels(const int &amp;score1, const int &amp;score2):&#160;gui.cc'],['../gui_8h.html#a71a1ac39fe89b4eaf3a7d4b0bc8c4633',1,'refresh_scores_labels(const int &amp;score1, const int &amp;score2):&#160;gui.cc']]],
  ['refresh_5fturn_5flabel',['refresh_turn_label',['../gui_8cc.html#a66894b02aa54394e24efddd4e0a8618c',1,'refresh_turn_label(bool _switch):&#160;gui.cc'],['../gui_8h.html#a66894b02aa54394e24efddd4e0a8618c',1,'refresh_turn_label(bool _switch):&#160;gui.cc']]],
  ['refresh_5funlocked',['refresh_unlocked',['../movements_8cc.html#a0c6790abf4708d31085f7f9f1ce5cf11',1,'refresh_unlocked():&#160;movements.cc'],['../movements_8h.html#a0c6790abf4708d31085f7f9f1ce5cf11',1,'refresh_unlocked():&#160;movements.cc']]],
  ['remove_5fdummies',['remove_dummies',['../cube_8cc.html#a1110dd053d1efc136f8ca21d94337298',1,'remove_dummies():&#160;cube.cc'],['../cube_8h.html#a1110dd053d1efc136f8ca21d94337298',1,'remove_dummies():&#160;cube.cc']]],
  ['reset_5fcell',['reset_cell',['../cube_8cc.html#a2ac814685fc40e4f78c8556c8e1112ce',1,'reset_cell(const int &amp;x, const int &amp;y, const int &amp;z):&#160;cube.cc'],['../cube_8h.html#a2ac814685fc40e4f78c8556c8e1112ce',1,'reset_cell(const int &amp;x, const int &amp;y, const int &amp;z):&#160;cube.cc']]],
  ['reset_5fhighlighted_5fcell',['reset_highlighted_cell',['../gui_8cc.html#a069e7212b25e5b8067dca2e396d2e864',1,'reset_highlighted_cell():&#160;gui.cc'],['../gui_8h.html#a069e7212b25e5b8067dca2e396d2e864',1,'reset_highlighted_cell():&#160;gui.cc']]],
  ['reset_5frow',['reset_row',['../game_8cc.html#a7c6eb3e4a7b7a457376c13e5bd2488e7',1,'reset_row():&#160;game.cc'],['../game_8h.html#a7c6eb3e4a7b7a457376c13e5bd2488e7',1,'reset_row():&#160;game.cc']]],
  ['right_5fcell',['right_cell',['../cube_8cc.html#a6d0082b30bf3657ac4fe5e6927349dee',1,'cube.cc']]],
  ['row',['row',['../game_8cc.html#af1d3cff2e4538e23400e260bae3dadad',1,'game.cc']]]
];
