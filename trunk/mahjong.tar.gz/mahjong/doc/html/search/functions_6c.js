var searchData=
[
  ['label_5ffrom_5fname',['label_from_name',['../gui_8cc.html#a7a91badc7d511d0c23bab04aa9c3fdaf',1,'gui.cc']]],
  ['left_5fcell',['left_cell',['../cube_8cc.html#ab9b8e3f5f92785a6e26779c9ede81d45',1,'cube.cc']]],
  ['load_5fgame',['load_game',['../game_8cc.html#a1e1dd2330c68191b8a43de87056b196a',1,'load_game(char *filename):&#160;game.cc'],['../game_8h.html#a1e1dd2330c68191b8a43de87056b196a',1,'load_game(char *filename):&#160;game.cc']]],
  ['load_5fgame_5ffrom_5ffile',['load_game_from_file',['../io__file_8cc.html#a77c49b87f96e6abbebfe50a84b7efd84',1,'load_game_from_file(couple **&amp;mov, const char *filename, int &amp;row, int &amp;col):&#160;io_file.cc'],['../io__file_8h.html#a77c49b87f96e6abbebfe50a84b7efd84',1,'load_game_from_file(couple **&amp;mov, const char *filename, int &amp;row, int &amp;col):&#160;io_file.cc']]]
];
