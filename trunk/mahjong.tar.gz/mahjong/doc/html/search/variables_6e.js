var searchData=
[
  ['name',['name',['../game_8h.html#af63b296d18a03f7e91badc96a015fac7',1,'name():&#160;io_file.cc'],['../io__file_8cc.html#af63b296d18a03f7e91badc96a015fac7',1,'name():&#160;io_file.cc']]]
];
