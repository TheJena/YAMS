var searchData=
[
  ['sand',['sand',['../gui_8cc.html#a4a7687a71bbde65541c51ed9a68576fe',1,'gui.cc']]],
  ['save_5fgame',['save_game',['../game_8cc.html#af558e3f525b0074b822ee6927b4467e9',1,'save_game(char *filename):&#160;game.cc'],['../game_8h.html#af558e3f525b0074b822ee6927b4467e9',1,'save_game(char *filename):&#160;game.cc']]],
  ['save_5fgame_5fon_5ffile',['save_game_on_file',['../io__file_8cc.html#a6f1b5e4cb147bb248c1a3070af68f420',1,'save_game_on_file(const couple **mov, char *filename, const int &amp;row, const int &amp;col):&#160;io_file.cc'],['../io__file_8h.html#a6f1b5e4cb147bb248c1a3070af68f420',1,'save_game_on_file(const couple **mov, char *filename, const int &amp;row, const int &amp;col):&#160;io_file.cc']]],
  ['seasonvalue',['SEASONVALUE',['../movements_8cc.html#a7ab690a4796436e64fb45093ec1382ac',1,'SEASONVALUE():&#160;movements.cc'],['../movements_8h.html#a7ab690a4796436e64fb45093ec1382ac',1,'SEASONVALUE():&#160;movements.cc']]],
  ['seedvalue',['SEEDVALUE',['../movements_8cc.html#a95139108e4b19e2552e5387d350d22eb',1,'SEEDVALUE():&#160;movements.cc'],['../movements_8h.html#a95139108e4b19e2552e5387d350d22eb',1,'SEEDVALUE():&#160;movements.cc']]],
  ['set_5fcoor_5ftile',['set_coor_tile',['../gui_8cc.html#ad1374732fac7a4fa82f52007e8db02e5',1,'gui.cc']]],
  ['set_5fhighlighted_5fcell',['set_highlighted_cell',['../gui_8cc.html#a8c97ed9e56d6d00d8e301c26c89eb411',1,'set_highlighted_cell(const int &amp;n, const int &amp;x, const int &amp;y, const int &amp;z):&#160;gui.cc'],['../gui_8h.html#a8c97ed9e56d6d00d8e301c26c89eb411',1,'set_highlighted_cell(const int &amp;n, const int &amp;x, const int &amp;y, const int &amp;z):&#160;gui.cc']]],
  ['sort_5fsub_5farray',['sort_sub_array',['../movements_8cc.html#a8f5a7d13e9ece437b2a8f33d52842592',1,'movements.cc']]],
  ['sort_5funlocked',['sort_unlocked',['../movements_8cc.html#a8d312079de155515dca7e89bb7d65771',1,'sort_unlocked():&#160;movements.cc'],['../movements_8h.html#a8d312079de155515dca7e89bb7d65771',1,'sort_unlocked():&#160;movements.cc']]],
  ['start_5fgame',['start_game',['../game_8cc.html#ad39fcaf7ee3bceadee96b0da22919849',1,'start_game():&#160;game.cc'],['../game_8h.html#ad39fcaf7ee3bceadee96b0da22919849',1,'start_game():&#160;game.cc']]],
  ['struct_5f_5fstring',['struct__string',['../game_8h.html#aa36e90616839acd7c66f56096c1b0ca1',1,'game.h']]],
  ['struct_5fcouple',['struct_couple',['../cube_8cc.html#a4c2392d3cec67a3c33abb2fa3c56608c',1,'struct_couple():&#160;cube.cc'],['../io__file_8h.html#a4c2392d3cec67a3c33abb2fa3c56608c',1,'struct_couple():&#160;io_file.h'],['../movements_8cc.html#a4c2392d3cec67a3c33abb2fa3c56608c',1,'struct_couple():&#160;movements.cc']]],
  ['struct_5ftile',['struct_tile',['../cube_8h.html#a0c8b688b240a3eddea598600ab9ee4e8',1,'cube.h']]],
  ['sub_5fpaint_5ftile',['sub_paint_tile',['../gui_8cc.html#a3a543ab731a5745657c5e47a3e7fc8b6',1,'gui.cc']]],
  ['swap_5ftiles',['swap_tiles',['../cube_8cc.html#aa31cac76e5645c1ecdf0e0875fefafc4',1,'cube.cc']]]
];
