var searchData=
[
  ['r',['r',['../structcolour.html#aec1c118c8b67a3911529dd573e5d7f79',1,'colour']]],
  ['row',['row',['../game_8cc.html#af1d3cff2e4538e23400e260bae3dadad',1,'game.cc']]]
];
