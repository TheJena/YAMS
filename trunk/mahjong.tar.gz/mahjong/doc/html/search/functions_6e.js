var searchData=
[
  ['number_5ffrom_5fstring',['number_from_string',['../gui_8cc.html#a778008c8bc092e89368f063a2fe429e6',1,'gui.cc']]],
  ['number_5fon_5ftile',['number_on_tile',['../gui_8cc.html#a3e2fa3e7a86e3616d47448482d5e52aa',1,'gui.cc']]]
];
