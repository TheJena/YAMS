var searchData=
[
  ['name',['name',['../game_8h.html#af63b296d18a03f7e91badc96a015fac7',1,'name():&#160;io_file.cc'],['../io__file_8cc.html#af63b296d18a03f7e91badc96a015fac7',1,'name():&#160;io_file.cc']]],
  ['ndebug',['NDEBUG',['../debug__macros_8h.html#a8de3ed741dadc9c979a4ff17c0a9116e',1,'debug_macros.h']]],
  ['number_5ffrom_5fstring',['number_from_string',['../gui_8cc.html#a778008c8bc092e89368f063a2fe429e6',1,'gui.cc']]],
  ['number_5fon_5ftile',['number_on_tile',['../gui_8cc.html#a3e2fa3e7a86e3616d47448482d5e52aa',1,'gui.cc']]]
];
