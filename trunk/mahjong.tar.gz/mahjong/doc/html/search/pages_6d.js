var searchData=
[
  ['mahjong',['Mahjong',['../index.html',1,'']]]
];
