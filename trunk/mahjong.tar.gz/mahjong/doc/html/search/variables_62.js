var searchData=
[
  ['b',['b',['../structcolour.html#aa02a4fc0faca4d1ca3d7532283862e84',1,'colour']]],
  ['black',['black',['../gui_8cc.html#a7c64c35bbd610144b8e20c07af5880ca',1,'gui.cc']]],
  ['blue_5fpersia',['blue_persia',['../gui_8cc.html#ab9cbe485a11e250d2fe68bb2b7422562',1,'gui.cc']]],
  ['builder',['builder',['../gui_8cc.html#afa501dbb63ae6077ac8db76b560de42b',1,'gui.cc']]]
];
