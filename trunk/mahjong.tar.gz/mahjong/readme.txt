Processo di installazione

1) scompattare l' archivio:
    tar zxvf mahjong.tar.gz mahjong

2) entrare nella cartella mahjong
    cd mahjong

3) entrare in src
    cd src

4) generare le dipendenze
    make depend

5) compilare il codice
    make
