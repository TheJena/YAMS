var searchData=
[
  ['tb_5ffrom_5fname',['tb_from_name',['../gui_8cc.html#ac9f7f76bacdd7ebabd0902c2bbf8a3b7',1,'gui.cc']]],
  ['tile_5fvalue',['tile_value',['../movements_8cc.html#a1e53b7a83063093036cd2956d3cf5698',1,'tile_value(const int &amp;name_position):&#160;movements.cc'],['../movements_8h.html#a1e53b7a83063093036cd2956d3cf5698',1,'tile_value(const int &amp;name_position):&#160;movements.cc']]],
  ['tiles',['TILES',['../cube_8cc.html#a92679829e7c7b60dac4d1c89739ecb9b',1,'TILES():&#160;cube.cc'],['../cube_8h.html#a92679829e7c7b60dac4d1c89739ecb9b',1,'TILES():&#160;cube.cc']]]
];
