var searchData=
[
  ['yellow',['yellow',['../gui_8cc.html#a5e7d6486579eec0c458103fcd05f16af',1,'gui.cc']]]
];
