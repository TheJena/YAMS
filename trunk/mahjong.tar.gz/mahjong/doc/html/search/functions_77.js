var searchData=
[
  ['widget_5ffrom_5fname',['widget_from_name',['../gui_8cc.html#a4bbffafa345ac66449949a88eac4017e',1,'gui.cc']]]
];
