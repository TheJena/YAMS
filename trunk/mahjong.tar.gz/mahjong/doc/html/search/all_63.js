var searchData=
[
  ['calculate_5fcoor_5fx_5fy',['calculate_coor_x_y',['../gui_8cc.html#a91de9fde97645d12aaffaf06ace7b286',1,'gui.cc']]],
  ['call_5fgtk_5fmain',['call_gtk_main',['../gui_8cc.html#a0044cd3ff3f394a99160e843209815b2',1,'call_gtk_main():&#160;gui.cc'],['../gui_8h.html#a0044cd3ff3f394a99160e843209815b2',1,'call_gtk_main():&#160;gui.cc']]],
  ['call_5fgtk_5fmain_5fquit',['call_gtk_main_quit',['../gui_8cc.html#aab082e5579b0e3b5ac93dcee582ba671',1,'call_gtk_main_quit():&#160;gui.cc'],['../gui_8h.html#aab082e5579b0e3b5ac93dcee582ba671',1,'call_gtk_main_quit():&#160;gui.cc']]],
  ['carmine',['carmine',['../gui_8cc.html#a8f6b159f02d259e1cb0bd8addd142c78',1,'gui.cc']]],
  ['check_5fcell',['check_cell',['../cube_8cc.html#a010ca8829412929daacf1609212ef81c',1,'cube.cc']]],
  ['check_5fconvenience',['check_convenience',['../cube_8cc.html#a0d1f86853c912caec788eba2a346b98b',1,'check_convenience(tile *a, tile *b, bool &amp;exit):&#160;cube.cc'],['../cube_8h.html#a0d1f86853c912caec788eba2a346b98b',1,'check_convenience(tile *a, tile *b, bool &amp;exit):&#160;cube.cc']]],
  ['check_5fcouple',['check_couple',['../game_8cc.html#af764be509d6d656189b4211d02cef767',1,'game.cc']]],
  ['check_5fcube',['check_cube',['../cube_8cc.html#a4f894e1b050b78df900502f825671049',1,'check_cube():&#160;cube.cc'],['../cube_8h.html#a4f894e1b050b78df900502f825671049',1,'check_cube():&#160;cube.cc']]],
  ['check_5ffilename',['check_filename',['../io__file_8cc.html#afffc0ec7fbe130f0cdade1e6f56db0b8',1,'io_file.cc']]],
  ['check_5fpair',['check_pair',['../movements_8cc.html#ae6ea84b766997de8ded162adc0c4f150',1,'movements.cc']]],
  ['check_5fposition',['check_position',['../gui_8cc.html#a625c8d792bb8bc790e5004e249acbdba',1,'gui.cc']]],
  ['clear_5fpair_5fremoved',['clear_pair_removed',['../gui_8cc.html#ad0c3b4925225878be8e12b0c43678fb4',1,'clear_pair_removed():&#160;gui.cc'],['../gui_8h.html#ad0c3b4925225878be8e12b0c43678fb4',1,'clear_pair_removed():&#160;gui.cc']]],
  ['coffe',['coffe',['../gui_8cc.html#a1b5be9bc86e77b529ccdedcab51da75c',1,'gui.cc']]],
  ['col',['col',['../game_8cc.html#afb52e720f5f0c483db5861f9e42e924e',1,'game.cc']]],
  ['colour',['colour',['../structcolour.html',1,'']]],
  ['count_5fpairs_5fremovable',['count_pairs_removable',['../movements_8cc.html#ac1ab19e53ac2166573cb5e81edd4df9a',1,'count_pairs_removable(const int &amp;count):&#160;movements.cc'],['../movements_8h.html#ac1ab19e53ac2166573cb5e81edd4df9a',1,'count_pairs_removable(const int &amp;count):&#160;movements.cc']]],
  ['create_5fcube',['create_cube',['../cube_8cc.html#ab98b6cc142d337143d37beddfd1f82a7',1,'create_cube():&#160;cube.cc'],['../cube_8h.html#ab98b6cc142d337143d37beddfd1f82a7',1,'create_cube():&#160;cube.cc']]],
  ['cube',['cube',['../cube_8cc.html#a9c7e833e00d7a833ef9dbda79155090c',1,'cube():&#160;cube.cc'],['../cube_8h.html#a9c7e833e00d7a833ef9dbda79155090c',1,'cube():&#160;cube.cc']]],
  ['cube_2ecc',['cube.cc',['../cube_8cc.html',1,'']]],
  ['cube_2eh',['cube.h',['../cube_8h.html',1,'']]]
];
