var searchData=
[
  ['_5fscore1',['_score1',['../game_8cc.html#ac4270932e53ca1f01055730603581ed5',1,'_score1():&#160;game.cc'],['../gui_8cc.html#ac4270932e53ca1f01055730603581ed5',1,'_score1():&#160;gui.cc']]],
  ['_5fscore2',['_score2',['../game_8cc.html#a54340bce4f156f70290ea284f25165ce',1,'_score2():&#160;game.cc'],['../gui_8cc.html#a54340bce4f156f70290ea284f25165ce',1,'_score2():&#160;gui.cc']]]
];
