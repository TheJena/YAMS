var searchData=
[
  ['handler_5fbutton_5fpressed_5fevent',['handler_button_pressed_event',['../gui_8cc.html#a179a787c209c364f980bcb50b3d0a575',1,'gui.cc']]],
  ['handler_5fclick_5fon_5fwidget',['handler_click_on_widget',['../gui_8cc.html#abf52fdccad349c2ca586d3b46643d1d1',1,'gui.cc']]],
  ['handler_5fdelete_5fevent',['handler_delete_event',['../gui_8cc.html#af41b4bf0ba2f0884b433dc12b71c1947',1,'gui.cc']]],
  ['handler_5fhide_5fwindow',['handler_hide_window',['../gui_8cc.html#ab28d730e2fb62d8adadec9a934778090',1,'gui.cc']]],
  ['handler_5fset_5fload_5fgame',['handler_set_load_game',['../gui_8cc.html#a7b8579db1330a707787a9c24ea9706bd',1,'gui.cc']]],
  ['handler_5fset_5fnew_5fgame',['handler_set_new_game',['../gui_8cc.html#a221a0314fe9d9bbad08147a916c0b222',1,'gui.cc']]],
  ['handler_5fset_5fsave_5fgame',['handler_set_save_game',['../gui_8cc.html#a8c199e6719ea594291b9a4044f36ea79',1,'gui.cc']]]
];
